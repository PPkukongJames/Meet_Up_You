<?php 
    session_start();
    include('server.php');
    $username = $_REQUEST["username"];
    $pass = $_REQUEST["pass"];
    $con_pass = $_REQUEST["con_pass"];
    $name = $_REQUEST["name"];

    if ($pass != $con_pass){
        $arr['StatusID'] = "0";;
        $arr['Error'] = "Password invalid!!!";
    }else{
        $ran = 0;
        while(True){
            $ran = rand(10000,99999);
            $check = "SELECT * FROM userr WHERE user_no=%u";
            $check = sprintf($check,$ran);
            $result = mysqli_query($conn,$check);
            $data = mysqli_fetch_row($result);
            if (empty($data)){
                break;
            }
        }
        $password = md5($pass);
        $sql = "INSERT INTO userr (user_no,username,PASSWORD,name,rate,Late,meet,yes) VALUES(%u,'%s','%s','%s',0,0,0,0)";
        $sql = sprintf($sql,$ran,$username,$password,$name);
        if(!(mysqli_query($conn,$sql))){
                $arr['StatusID'] = "0";
                $arr['Error'] = "Cannot save data!";
            }else{
                $arr['StatusID'] = "1";
                $arr['Error'] = "";
            }
        echo json_encode($arr);
    }
?>
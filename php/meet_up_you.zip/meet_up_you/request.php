<?php
    session_start();
    include('server.php');
    $user_no = $_REQUEST['user_no'];
    $meet_no = $_REQUEST['meet_no'];
    $Aws = $_REQUEST['awswer'];
    $check = "SELECT * FROM meet_up WHERE user_no=%u and meet_no=%u";
    $check = sprintf($check,$user_no,$meet_no);
    $result = mysqli_query($conn,$check);
    $data = mysqli_fetch_row($result);
    if(empty($data)){
        $arr['StatusID'] = "0";
        $arr['Error'] = "not found!";
        echo json_encode($arr);
    }else{
        $sql = "UPDATE meet_up SET status='%s' WHERE user_no=%u and meet_no=%u";
        if($Aws == "1"){
            $sql = sprintf($sql,"accept",$user_no,$meet_no);
            mysqli_query($conn,$sql);
        }else if($Aws == "0"){
            $sql = sprintf($sql,"deny",$user_no,$meet_no);
            mysqli_query($conn,$sql);
        }
        $arr['StatusID'] = "1";
        $arr['Error'] = "success";
        echo json_encode($arr);
    }
?>
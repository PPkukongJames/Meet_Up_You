<?php
    session_start();
    include('server.php');
    $user_no = $_REQUEST["user_no"];
    $check = "SELECT * FROM meet_up WHERE user_no=%u";
    $check = sprintf($check,$user_no);
    $result = mysqli_query($conn,$check);
    while($row=mysqli_fetch_row($result)){
        $out['meet_no'] = $row[0];
        $out['user_no'] = $row[1];
        $out['title'] = $row[2];
        $out['s_Day'] = $row[3];
        $out['s_Month'] = $row[4];
        $out['s_Year'] = $row[5];
        $out['s_hour'] = $row[6];
        $out['s_min'] = $row[7];
        $out['detail'] = $row[8];
        $out['status'] = $row[9];
        $out['person_no'] = $row[10];
        $sql = "SELECT name FROM userr WHERE user_no=%u";
        $sql = sprintf($sql,$row[10]);
        $result_2 = mysqli_query($conn,$sql);
        $person_name = mysqli_fetch_row($result_2);
        $out['person_name'] = $person_name[0];
        $arr_temp[] =$out;
    }
    if(empty($arr_temp)){
        $arr['StatusID'] = "0";
        $arr['Error'] = "not found";
    }else{
        $arr['StatusID'] = "1";
        $arr['Error'] = "success";
        $arr['data'] = $arr_temp;
    }
    echo json_encode($arr);
?>
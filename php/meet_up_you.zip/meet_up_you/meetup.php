<?php 
    session_start();
    include('server.php');
    while(True){
        $ran = rand(10000,99999);
        $check = "SELECT * FROM meet_up WHERE meet_no=%u";
        $check = sprintf($check,$ran);
        $result = mysqli_query($conn,$check);
        $data = mysqli_fetch_row($result);
        if (empty($data)){
            break;
        }
    }
    $user_no = $_REQUEST["user_no"];
    $title = $_REQUEST["title"];
    $day = $_REQUEST["day"];
    $month = $_REQUEST["month"];
    $year = $_REQUEST["year"];
    $hour = $_REQUEST["hour"];
    $min = $_REQUEST["min"];
    $detail = $_REQUEST["detail"];
    $person_no = $_REQUEST["person_no"];
    $check = "SELECT * FROM meet_up WHERE user_no=%u and person_no=%u and s_Day=%u and s_Month=%u and s_Year=%u and s_hour=%u and s_min=%u";
    $check = sprintf($check,$user_no,$person_no,$day,$month,$year,$hour,$min);
    $result = mysqli_query($conn,$check);
    $data = mysqli_fetch_row($result);
    if (empty($data)){
        $sql="INSERT INTO meet_up(meet_no,user_no,title,s_Day,s_Month,s_Year,s_hour,s_min,detail,status,person_no) VALUES(%u,%u,'%s',%u,%u,%u,%u,%u,'%s','%s',%u)";
        $sql = sprintf($sql,$ran,$user_no,$title,$day,$month,$year,$hour,$min,$detail,"waiting",$person_no);
        (mysqli_query($conn,$sql));
        $selete = "SELECT * FROM meet_up WHERE user_no=%u";
        $selete = sprintf($selete,$user_no);

        $result = mysqli_query($conn,$selete);
        
        while($row=mysqli_fetch_row($result)){
            $out['meet_no'] = $row[0];
            $out['user_no'] = $row[1];
            $out['title'] = $row[2];
            $out['s_Day'] = $row[3];
            $out['s_Month'] = $row[4];
            $out['s_Year'] = $row[5];
            $out['s_hour'] = $row[6];
            $out['s_min'] = $row[7];
            $out['detail'] = $row[8];
            $out['status'] = $row[9];
            $out['person_no'] = $row[10];
            $arr_temp[] =$out;
        }
        $arr['StatusID'] = "1";
        $arr['Error'] = "Time stamp";
        $arr['data'] = $arr_temp;
        echo json_encode($arr);
    }else{
        $arr['StatusID'] = "0";
        $arr['Error'] = "Time not empty!!!";
        echo json_encode($arr);
    }

?>
<!-- http://localhost/meet_up_you/insert_data.php?user_no=56401&=A&day=12&month=12&year=2022&time=12.22&detail=testA&status=waiting&person_no=89696 -->
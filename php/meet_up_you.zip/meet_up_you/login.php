<?php 
    session_start();
    include('server.php');
    $username = $_REQUEST["username"];
    $pass = $_REQUEST["pass"];
    $password = md5($pass);
    $sql = "SELECT * FROM userr WHERE username='%s' AND PASSWORD=%u";
    $sql = sprintf($sql,$username,$password);
    $result = mysqli_query($conn,$sql);
    $count = mysqli_num_rows($result);
    if(!($result) and $count==0){
        $arr['StatusID'] = "0";
        $arr['Error'] = "Username or Password invalid!!!";
        $arr['number'] = "-";
    }else{
        $user_no = mysqli_fetch_row($result)[0];
        $arr['StatusID'] = "1";
        $arr['Error'] = "";
        $arr['number'] =$user_no;
    }
    echo json_encode($arr);
?>

